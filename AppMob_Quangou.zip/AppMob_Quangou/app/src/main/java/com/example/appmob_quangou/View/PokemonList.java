package com.example.appmob_quangou.View;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.appmob_quangou.Adapter.PokemonListAdapter;
import com.example.appmob_quangou.Common.Common;
import com.example.appmob_quangou.Common.ItemOffsetDecoration;
import com.example.appmob_quangou.Model.Poke;
import com.example.appmob_quangou.Model.pokemon;
import com.example.appmob_quangou.R;
import com.example.appmob_quangou.Retrofit.IPokemonDex;
import com.example.appmob_quangou.Retrofit.RetrofitClient;
import com.mancj.materialsearchbar.MaterialSearchBar;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import retrofit2.Retrofit;


/**
 * A simple {@link Fragment} subclass.
 */
public class PokemonList extends Fragment {

    IPokemonDex iPokemonDex;
    CompositeDisposable compositeDisposable = new CompositeDisposable();
    RecyclerView pokemon_list_recyclerview;
    PokemonListAdapter adapter,search_adapter;
    List<String> last_suggest = new ArrayList<>();

    MaterialSearchBar searchBar;

    @SuppressLint("StaticFieldLeak")
    static PokemonList instance;
    public static PokemonList getInstance(){
        if (instance == null)
            instance = new PokemonList();
        return instance;
    }


    public PokemonList() {
        // Required empty public constructor
        Retrofit retrofit = RetrofitClient.getInstace();
        iPokemonDex = retrofit.create(IPokemonDex.class);
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pokemon_list, container, false);
        pokemon_list_recyclerview = view.findViewById(R.id.pokemon_list_recyclerview);
        pokemon_list_recyclerview.setHasFixedSize(true);
        pokemon_list_recyclerview.setLayoutManager(new GridLayoutManager(getActivity(),2));
        ItemOffsetDecoration itemOffsetDecoration = new ItemOffsetDecoration(Objects.requireNonNull(getActivity()),R.dimen.spacing);
        pokemon_list_recyclerview.addItemDecoration(itemOffsetDecoration);

        searchBar = (MaterialSearchBar)view.findViewById(R.id.search_bar);
        searchBar.setHint("Entrez le nom du pokemon");
        searchBar.setCardViewElevation(10);
        searchBar.addTextChangeListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                List<String> suggest = new ArrayList<>();
                for (String search:last_suggest){
                    if(search.toLowerCase().contains(searchBar.getText().toLowerCase()))
                        suggest.add(search);
                }
                searchBar.setLastSuggestions(suggest);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        searchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {
                if(!enabled)
                    pokemon_list_recyclerview.setAdapter(adapter);// retourner l'adapter par défaut
            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                startSeach(text);
            }

            @Override
            public void onButtonClicked(int buttonCode) {

            }
        });

        fetchData();
        return view;
    }

    private void startSeach(CharSequence text) {
        if(Common.commonPokemonList.size()> 0){
            List<pokemon> result = new ArrayList<>();
            for (pokemon poke:Common.commonPokemonList){
                if(poke.getName().toLowerCase().contains(text.toString().toLowerCase()))
                    result.add(poke);
                search_adapter = new PokemonListAdapter(getActivity(),result);
                pokemon_list_recyclerview.setAdapter(search_adapter);
        }
    }}

    private void fetchData() {
        compositeDisposable.add(iPokemonDex.getListPokemon()
        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Consumer<Poke>() {
                @Override
                public void accept(Poke poke) {
                    Common.commonPokemonList = poke.getPokemon();
                    adapter = new PokemonListAdapter(getActivity(),Common.commonPokemonList);

                    pokemon_list_recyclerview.setAdapter(adapter);
                    last_suggest.clear();
                    for (pokemon pokemon:Common.commonPokemonList )
                        last_suggest.add(pokemon.getName());
                    searchBar.setVisibility(View.VISIBLE);
                    searchBar.setLastSuggestions(last_suggest);


                }
            })

        );
    }

}
