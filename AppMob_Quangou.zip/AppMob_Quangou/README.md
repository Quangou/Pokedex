POKEDEX
==
HOANG Jacky
-
Date Upload1 : 04/04/2019

Projet basique d'application sur AndroidSTUDIO
Version 1.1

utilisation : *java* ,*retrofit* , *recycleview*, *cardview*

Résumé des différentes fonctionnalités :
-
+ Deux écrans : une liste de pokémon (scrollable) et un détail du pokémon au click de celui ci 
+ Appel à un WEBSERVICE à une API REST :https://raw.githubusercontent.com/Biuni/PokemonGO-Pokedex/master/pokedex.json


Lancement de l'application :
-

![icone](https://user-images.githubusercontent.com/47207720/55428941-86fbaf80-558a-11e9-8de9-63a92e84f3b2.jpg)

L'icone de démarrage de l'application n'est pas celle par défaut elle utilise une image '.png' 512*512.


![Liste scrollable des pokémons](https://user-images.githubusercontent.com/47207720/55429033-bdd1c580-558a-11e9-8483-9526aa2b0529.PNG)

Voici la liste des pokémons , il suffit de cliquer sur un pour en avoir les informations.

![details pokemon](https://user-images.githubusercontent.com/47207720/55432950-7ea87200-5594-11e9-8d7a-a943a194363e.PNG)

On choisit un pokemon au hasard ses informations sont visibles sur un deuxième écran avec les caractéristiques,types,faiblesses,évolutions.

![detail pokémon 1](https://user-images.githubusercontent.com/47207720/55432994-a1d32180-5594-11e9-8e57-25b8586b1a8f.PNG)

Remarquez que certains pokémons ont plusieurs types et faiblesses elles apparaissent en scrollant (droite à gauche).

![évolution pokemon](https://user-images.githubusercontent.com/47207720/55433060-cc24df00-5594-11e9-84dc-1ac28700ec51.PNG)

En cliquant sur l'évolution du pokémon choisi on obtient à l'écran les informations de celui ci.


![pokedetailevol2](https://user-images.githubusercontent.com/47207720/55433088-e6f75380-5594-11e9-9f11-6a4536314a60.PNG)

Voici la dernière évolution du pokémon , en cliquant sur ses prévolutions on obtient la même chose (avec les anciennes évolutions).


![backbutton](https://user-images.githubusercontent.com/47207720/55433112-f5de0600-5594-11e9-8ae3-182ba4c3f710.PNG)

Remarquez le bouton de retour en haut à gauche , il permet de revenir au menu sans utiliser le bouton back du smartphone (autrement le nom du pokémon reste affiché sur le layout).

Prochaines fonctionnalités:
-
+ A déterminer
