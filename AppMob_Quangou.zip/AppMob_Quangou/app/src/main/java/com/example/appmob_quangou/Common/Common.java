package com.example.appmob_quangou.Common;

import android.content.Intent;
import android.graphics.Color;

import com.example.appmob_quangou.Model.pokemon;

import java.util.ArrayList;
import java.util.List;

public class Common {

    public static final String KEY_NUM_EVOLUTION ="num_evolution" ;
    public static List<pokemon> commonPokemonList = new ArrayList<>();
    public static final String KEY_ENABLE_HOME="enable_home";

    public static int TypeColor(String type) {
        switch (type)
        {
            case "Normal":
                return Color.parseColor("gray");

            case "Fight":
                return Color.parseColor("#d10000");

            case "Dragon":
                return Color.parseColor("#743BFB");


            case "Psychic":
                return Color.parseColor("#F15B85");


            case "Electric":
                return Color.parseColor("#ffc61c");


            case "Ground":
                return Color.parseColor("#8c5210");


            case "Grass":
                return Color.parseColor("#20c918");

            case "Poison":
                return Color.parseColor("#d817c8");

            case "Steel":
                return Color.parseColor("#8e8c86");


            case "Fairy":
                return Color.parseColor("#f477f0");


            case "Fire":
                return Color.parseColor("#F48130");


            case "Bug":
                return Color.parseColor("#A8B822");


            case "Ghost":
                return Color.parseColor("#705693");


            case "Dark":
                return Color.parseColor("#745945");


            case "Ice":
                return Color.parseColor("#aacbe2");


            case "Water":
                return Color.parseColor("#379fe8");
            default:
                return Color.parseColor("#658FA0");

        }
    }

    public static pokemon findPokemonByNum(String num) {
        for (pokemon Pokemon:Common.commonPokemonList){
            if (Pokemon.getNum().equals(num)){
                return Pokemon;
            }
        } return null;

}}
