package com.example.appmob_quangou.View;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.appmob_quangou.Common.Common;
import com.example.appmob_quangou.Model.pokemon;
import com.example.appmob_quangou.R;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private final String TAG = this.getClass().getName();


    public void ShowMess(){
        Toast.makeText(getApplicationContext(), "Application mobile Jacky HOANG classe 34", Toast.LENGTH_LONG).show();
    }

    Toolbar toolbar;
    BroadcastReceiver ShowDetail = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().toString().equals(Common.KEY_ENABLE_HOME)){
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setDisplayShowHomeEnabled(true);

                Fragment detailFragment = PokemonInfo.getInstance();
                String num = intent.getStringExtra("num");
            Bundle bundle = new Bundle();
            bundle.putString("num",num);
            detailFragment.setArguments(bundle);

                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.list_pokemon_fragment,detailFragment);
                fragmentTransaction.addToBackStack("info");
                fragmentTransaction.commit();

                pokemon Pokemon = Common.findPokemonByNum(num);
                toolbar.setTitle(Pokemon.getName());
            }

        }
    };

    BroadcastReceiver ShowEvolution = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(intent.getAction().toString().equals(Common.KEY_NUM_EVOLUTION)){


                Fragment detailFragment = PokemonInfo.getInstance();
                Bundle bundle = new Bundle();
                String num = intent.getStringExtra("num");
                bundle.putString("num",num);
                detailFragment.setArguments(bundle);

                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.remove(detailFragment);
                fragmentTransaction.replace(R.id.list_pokemon_fragment,detailFragment);
                fragmentTransaction.addToBackStack("info");
                fragmentTransaction.commit();

                pokemon Pokemon = Common.findPokemonByNum(num);
                toolbar.setTitle(Pokemon.getName());
            }

        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setTitle("LISTE POKEMON");
        setSupportActionBar(toolbar);
        ShowMess();

        LocalBroadcastManager.getInstance(this)
                .registerReceiver(ShowDetail,new IntentFilter(Common.KEY_ENABLE_HOME));

        LocalBroadcastManager.getInstance(this)
                .registerReceiver(ShowEvolution,new IntentFilter(Common.KEY_NUM_EVOLUTION));


       /* FileCacher<String> stringCacher = new FileCacher<>(MainActivity.this, "sometext.txt");
        try{
            stringCacher.writeCache("texte qui sera écrit dans le cache");
        }catch (IOException e) {
            e.printStackTrace();
        }
        if(stringCacher.hasCache()){
            try{
           String text = stringCacher.readCache();
                Log.d(TAG, text);

        }catch (IOException e){
            e.printStackTrace();
        }}
*/
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                toolbar.setTitle("Liste Pokémon");
                //Enlève l'écran d'info et revient à l'écran liste pokemon
                getSupportFragmentManager().popBackStack("info", FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Objects.requireNonNull(getSupportActionBar()).setDisplayShowHomeEnabled(false);
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);

                break;
                default:
                    break;
        }
        return true;
    }
}
