package com.example.appmob_quangou.Retrofit;

import com.example.appmob_quangou.Model.Poke;

import io.reactivex.Observable;
import retrofit2.http.GET;

public interface IPokemonDex {
    @GET("pokedex.json")
    Observable<Poke> getListPokemon();
}
