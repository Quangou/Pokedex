package com.example.appmob_quangou.Model;

import java.util.List;

public class Poke
{
    private List<pokemon> pokemon ;


    public Poke(List<pokemon> pokemon) {
        this.pokemon = pokemon;
    }

    public List<pokemon> getPokemon() {
    return pokemon;
}

    public void setPokemon(List<pokemon> pokemon) {
        this.pokemon = pokemon;
    }
}