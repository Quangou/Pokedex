package com.example.appmob_quangou.Interface;

import android.view.View;

public interface IItemClickListener {

    void OnClick(View view , int position);
}
