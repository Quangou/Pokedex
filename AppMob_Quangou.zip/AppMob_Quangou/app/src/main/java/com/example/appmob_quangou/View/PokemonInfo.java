package com.example.appmob_quangou.View;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.appmob_quangou.Adapter.PokemonEvolutionAdapter;
import com.example.appmob_quangou.Adapter.PokemonTypeAdapter;
import com.example.appmob_quangou.Common.Common;
import com.example.appmob_quangou.Model.pokemon;
import com.example.appmob_quangou.R;


public class PokemonInfo extends Fragment {


    ImageView pokemon_img;
    TextView pokemon_nom,pokemon_taille,pokemon_poid;
    RecyclerView recycler_type,recycler_faiblesse,recycler_evolution,recycler_prevol;
    static PokemonInfo instance;

    public static PokemonInfo getInstance() {
        if(instance == null)
            instance = new PokemonInfo();
        return instance;
    }


    public PokemonInfo() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View itemView = inflater.inflate(R.layout.fragment_pokemon_info, container, false);

        pokemon Pokemon = Common.findPokemonByNum(getArguments().getString("num"));

        pokemon_img = (ImageView)itemView.findViewById(R.id.pokemon_image);
        pokemon_nom = (TextView)itemView.findViewById(R.id.nom);
        pokemon_taille = (TextView)itemView.findViewById(R.id.Taille);
        pokemon_poid = (TextView)itemView.findViewById(R.id.Poid);

        recycler_type = (RecyclerView)itemView.findViewById(R.id.recycler_type);
        recycler_type.setHasFixedSize(true);
        recycler_type.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false));

        recycler_faiblesse = (RecyclerView)itemView.findViewById(R.id.recycler_Faiblesse);
        recycler_faiblesse.setHasFixedSize(true);
        recycler_faiblesse.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false));

        recycler_evolution = (RecyclerView)itemView.findViewById(R.id.recycler_Evolution);
        recycler_evolution.setHasFixedSize(true);
        recycler_evolution.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false));

        recycler_prevol = (RecyclerView)itemView.findViewById(R.id.recycler_Pre_Evolution);
        recycler_prevol.setHasFixedSize(true);
        recycler_prevol.setLayoutManager(new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false));


        setDetailPokemon(Pokemon);
        
        return itemView;
    }

    private void setDetailPokemon(pokemon pokemon) {
        Glide.with(getActivity()).load(pokemon.getImg()).into(pokemon_img);
        pokemon_nom.setText(pokemon.getName());
        pokemon_poid.setText("Poid: "+pokemon.getWeight());
        pokemon_taille.setText("Taille: "+pokemon.getHeight());

        //Type
        PokemonTypeAdapter typeAdapter = new PokemonTypeAdapter(getActivity(),pokemon.getType());
        recycler_type.setAdapter(typeAdapter);

        //Faiblesse

        PokemonTypeAdapter faiblesseAdapter = new PokemonTypeAdapter(getActivity(),pokemon.getWeaknesses());
        recycler_faiblesse.setAdapter(faiblesseAdapter);

        //Evolution

        PokemonEvolutionAdapter prevolutionAdapter = new PokemonEvolutionAdapter(getActivity(),pokemon.getPrev_evolution());
        recycler_prevol.setAdapter(prevolutionAdapter);

        PokemonEvolutionAdapter evolutionAdapter = new PokemonEvolutionAdapter(getActivity(),pokemon.getNext_evolution());
        recycler_evolution.setAdapter(evolutionAdapter);

    }


}

